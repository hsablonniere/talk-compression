const foo = [
  { name: 'John' },
  { name: 'Paul' },
];
